# Plan for the first two CS6158 project milestones

Prepared from both pages of CS6158 Project Proposal.pdf and the official sources linked below. The workspace initially contained only the proposal. This document is a plan; dependencies, models, datasets, and training have not been installed or run.

## 1. What we are building

The project is a controlled empirical study of training-data source and model size. Its core experiment is three Qwen2.5-Coder sizes (1.5B, 3B, 7B) trained on three data sources (SWE-Gym, SWE-smith, SWE-Master-derived data), producing nine adapted models. Three corresponding unmodified checkpoints provide baselines. All twelve conditions use the same agent, tools, inference limits, and approximately 100 SWE-bench Verified tasks.

We measure task resolution, gains over each matching baseline, training GPU hours and memory, and inference tokens, steps, tool calls, runtime, and timeouts. Published systems provide context; their full-benchmark scores are not controlled comparisons to our subset. Reproducing their RL, verifier, or best-of-N pipelines is outside these milestones.

The proposal's date ranges below remain milestone labels. If executing after those dates, preserve the dependencies and completion checks when rescheduling.

## 2. Decisions to make before implementation

| Decision | Proposed choice | Reason / condition |
| --- | --- | --- |
| Initial checkpoints | Qwen/Qwen2.5-Coder-1.5B-Instruct, Qwen/Qwen2.5-Coder-3B-Instruct, Qwen/Qwen2.5-Coder-7B-Instruct | Use instruction-following models for a conversational tool agent. The proposal does not specify Base versus Instruct; this is a recommendation. Hereafter, baseline means the same Instruct checkpoint without our adapter. |
| Core training method | Supervised fine-tuning with LoRA | One method keeps the nine-run design interpretable. DPO requires preference pairs and extra conditions; retain it as an extension. |
| Agent scaffold | Pinned SWE-Gym/OpenHands CodeActAgent fork, subject to the compatibility check below | It provides a direct starting point for the released SWE-Gym trajectories. The authors warn that newer OpenHands versions can change results. [OpenHands reproduction guide](https://github.com/SWE-Gym/SWE-Gym/blob/main/docs/OpenHands.md). |
| Execution platform | WSL2 Ubuntu on the local Windows machine, with NVIDIA GPU support and Docker integration | User confirmed a local NVIDIA GPU. GPU model and usable VRAM are still unknown. Verify both inside WSL before model downloads. |
| Software stack | Separate pinned environments for agent, official evaluation, and PyTorch + Transformers + Datasets + PEFT + TRL training; vLLM for serving if supported by local hardware | Keep the older agent dependencies separate from modern training/serving dependencies. Exchange predictions, adapters, and HTTP requests through explicit interfaces. |
| Numeric precision | Profile BF16 LoRA first if supported; use 4-bit QLoRA if necessary | Choose one training quantization policy for all nine main runs. Keep inference precision consistent across all twelve conditions and record it separately. [PEFT quantization guide](https://huggingface.co/docs/peft/developer_guides/quantization). |
| Context | Target a shared maximum of 32,768 tokens; use 4K-8K only for early smoke tests | The smaller model cards specify 32,768 tokens. Choose a feasible common production limit after profiling all sizes; reserve space for generated output. [1.5B](https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct), [3B](https://huggingface.co/Qwen/Qwen2.5-Coder-3B-Instruct). |

Do not freeze the scaffold based on SWE-Gym alone. During milestone 1, inspect a few real examples from each intended source and build a tool mapping table: command name, arguments, behavior, state, and observation format. SWE-smith trajectories originate from SWE-agent, while SWE-Master uses an R2E-Gym-based framework. Renaming roles into a common messages field does not preserve tool semantics. Verify representative converted calls against fixtures before committing to the common interface. Unsupported actions require a justified exclusion or new trajectories collected under the shared scaffold; estimate that cost before large runs. [SWE-smith release](https://huggingface.co/datasets/SWE-bench/SWE-smith-trajectories), [SWE-Master implementation](https://github.com/RUCAIBox/SWE-Master).

Also verify that the intended SWE-Master training trajectories are actually downloadable with sufficient provenance. Code and demonstration files alone do not establish availability of the full training release. Record the exact artifact or a regeneration requirement now; full processing remains milestone 3.

## 3. Milestone 1: Sep 14-27 - SWE-bench, models, and scaffold

**Completion target:** starting from a clean checkout, a documented command can load any of the three checkpoints, run the shared agent on a development task, export a patch, and produce an official SWE-bench grading report.

### A. Establish the local environment and version manifest

Owner: Weitao for GPU/model setup; Qingyao for Docker, scaffold, and grader.

1. Record GPU model, total and free VRAM, driver, CUDA compatibility, WSL distribution, CPU/RAM, and free disk space. Run a small CUDA tensor operation inside WSL and a Docker hello-world check.
2. Keep active repositories and datasets in the WSL Linux filesystem for execution; keep this Windows workspace as the planning/source handoff location if needed.
3. Create independent environments for the three components above. Pin package versions, repository commit hashes, dataset revisions, tokenizer revisions, and Docker image digests after the first working smoke test.
4. Start with one evaluation worker and pull/build only the images needed for the pilot. The official harness recommends x86_64, 8 CPU cores, 16 GB RAM, and at least 120 GB free storage. Plan additional space for OpenHands runtime images, model weights, and checkpoints. [Official setup](https://github.com/SWE-bench/SWE-bench), [Windows Docker guide](https://github.com/SWE-bench/SWE-bench/blob/main/docs/guides/docker_setup.md).

Deliverables: environment instructions, dependency locks, hardware report, and version manifest. Do not assume a GPU that loads 7B weights can train long-context 7B adapters.

### B. Verify the evaluator independently of the model

Owner: Qingyao.

1. Install the official SWE-bench harness at a fixed revision. Use the CLI and task/image requirements of that revision; do not mix commands from unrelated releases.
2. On one documented reference instance, evaluate the supplied gold patch and confirm the expected resolved result. Evaluate a blank patch as a negative control and inspect the test log.
3. Repeat this setup check on a few tasks from different repositories. Separate image/build failures from patch application failures and test failures.
4. Assign a fresh run ID to each distinct prediction artifact. The current harness documents result caching by run ID and instance ID. [Harness documentation](https://github.com/SWE-bench/SWE-bench).

Deliverables: reference and negative-control prediction files, official reports, and test/build logs. Gold patches and hidden evaluation tests stay in the grading process, outside the agent's accessible workspace.

### C. Freeze task lists and evaluation policy

Owner: Qingyao; both review.

1. Create a development list of 5-10 tasks from a disjoint development split or held-out SWE-Gym tasks, checked against Verified. Use it for prompt, parser, and integration debugging.
2. Select 100 Verified tasks with a fixed seed, proportional repository coverage, and a documented rounding rule. Save the ordered instance IDs and dataset revision before looking at model success rates. Use the full Verified set as a contamination denylist during data preparation.
3. Perform infrastructure checks on the selected tasks. Keep a fixed denominator and a documented infrastructure-failure policy; never replace tasks because a model struggles with them.
4. Define a provisional policy: one attempt per task, temperature 0, maximum 30 agent steps, up to 2,048 generated tokens per response, a 30-minute task timeout, and a fixed cumulative generation cap (initial candidate: 32K tokens). Freeze production values after development checks and GPU profiling. Keep prompt, tools, history management, observation limits, and retry policy identical across conditions.
5. Do not tune checkpoints or prompts on the final 100-task scores. The full baseline evaluations can occur with the later evaluation milestone; these first two milestones need development smoke results.

Deliverables: development and final task manifests, seed/sampling script, and evaluation configuration.

### D. Load the models and connect the scaffold

Owner: Weitao for checkpoint loading/serving; Qingyao for integration.

1. Download exact checkpoint and tokenizer revisions, starting with 1.5B. Load one model at a time. Verify deterministic generation and a representative tool action for each size.
2. Configure one serving interface and verify how it renders the chat template and tool definitions. Avoid applying the chat template twice. A vLLM-compatible serving example is available on the [Qwen model card](https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct).
3. Configure the pinned CodeActAgent to inspect files, modify code, run commands/tests, observe feedback, and finish. Retain the training-compatible action protocol. Disable optional tools that are not part of the agreed experiment.
4. Log the model identity, raw model responses, parsed actions, observations, tool errors, finish reason, patch, input/output token counts, tool calls, steps, runtime, and timeouts.
5. First replay a known valid action sequence to test parser/runtime behavior. Then run all three unmodified models on the same development list. A low resolution rate can be a valid baseline; parser or grader failures are not evidence of model capability.
6. Export one JSONL prediction per task with instance_id, model_name_or_path, and model_patch, then grade with the official harness. [OpenHands evaluation interface](https://github.com/SWE-Gym/OpenHands/blob/main/evaluation/swe_bench/README.md).

Deliverables: working rollout/export/grade commands, three development baseline logs, representative trajectories, and memory/latency measurements.

### Suggested sequence

| Period | Work | Lead | Evidence |
| --- | --- | --- | --- |
| Sep 14-16 | Hardware, WSL/Docker, isolated environments | Both | CUDA and container checks; version manifest |
| Sep 17-19 | Official grader controls, task manifests; cross-source tool audit | Qingyao; Weitao audits data | Gold/blank reports; fixed IDs; compatibility findings |
| Sep 20-23 | Model serving, pinned scaffold, patch export | Both | One complete model-to-grader execution |
| Sep 24-27 | Three-size development pilots; freeze shared interfaces | Both | Comparable logs, resource profile, documented policy |

**Milestone 1 passes when:** evaluator controls behave as expected; all three models complete the rollout/export/grading workflow on development tasks; errors and costs are logged; the final task list is fixed; and the shared tool interface has an explicit compatibility decision.

## 4. Milestone 2: Sep 28-Oct 11 - SWE-Gym preparation and LoRA validation

**Completion target:** a versioned, audited SWE-Gym dataset and a small validated adapter that reloads and runs through the milestone 1 agent and grader. Final nine-run training belongs to later milestones.

### A. Acquire the right SWE-Gym artifacts

Owner: Weitao.

Start from SWE-Gym/OpenHands-SFT-Trajectories, split train.success.oss, currently 491 rows. This is the ready-made successful SFT release, distinct from SWE-Gym/SWE-Gym's approximately 2,438 executable tasks. Use SWE-Gym/OpenHands-Sampled-Trajectories, split train.raw, as a provenance resource where needed; its schema includes instance_id, run_id, resolved, messages, tools, and test_result. Do not train on the unfiltered sampled pool. [SFT release](https://huggingface.co/datasets/SWE-Gym/OpenHands-SFT-Trajectories), [sampled release](https://huggingface.co/datasets/SWE-Gym/OpenHands-Sampled-Trajectories), [project](https://github.com/SWE-Gym/SWE-Gym).

Save source revisions, file hashes, licensing notes, and original row references. The SFT viewer exposes messages without explicit task IDs, so recover IDs by validated matching against the sampled release or original task prompts. Quarantine ambiguous matches instead of inventing provenance.

### B. Normalize, audit, and split before training

Owner: Weitao; Qingyao verifies tool compatibility.

1. Preserve system prompt, issue, assistant actions, tool observations, finish behavior, and tool definitions or their exact prompt representation. Keep an external manifest with source, row reference, instance ID, repository, trajectory hash, teacher/run information when available, and transformation version.
2. Reject malformed histories, missing tool-call/result pairs, unsupported actions, ambiguous task identity, and zero-target-token examples. Preserve recovered mistakes within an ultimately successful trajectory; do not delete intermediate failed commands indiscriminately.
3. Deduplicate by task ID and normalized trajectory hash; inspect near-duplicate issue/patch matches. Check against all Verified task IDs and available issue/patch fingerprints. Record detected overlap and unresolved uncertainty; public-source checks cannot establish that the pretrained models never saw a benchmark task.
4. Assign roughly 90%/10% train/validation at the task level before expanding trajectories into per-turn examples or chunks. All trajectories and derived examples from one task stay together. Keep pilot evaluation tasks out of training too.
5. Tokenize with the actual pinned tokenizer and chat/tool template. Verify whether tokenization is identical across the three sizes. Report raw/retained task counts, trajectories, steps, total non-padding tokens, assistant target tokens, and length percentiles.
6. Choose a context policy from the length histogram and GPU profile. Prefer intact trajectories that fit. If longer histories require per-turn examples, preserve the system prompt and issue, keep complete action/observation units, and apply a documented history policy compatible with inference. Never silently truncate the successful ending or split a tool call. Report exclusions and any length-selection bias by source.
7. Implement token accounting for later matched subsets now, but set the final cross-source budget after the other sources are audited in milestone 3. Record both processed tokens and loss-bearing assistant tokens. The usable SWE-Gym pool may constrain the matched budget; repeating a small dataset is not additional unique data.

Deliverables: processed train/validation JSONL, provenance manifests, exclusion/overlap reports, length statistics, and tokenizer/template hashes.

### C. Validate the loss mask before spending GPU time

Owner: Weitao.

Use assistant-only SFT: assistant text/actions and appropriate end markers receive labels; system, user, environment observations, and padding receive -100. Preserve tool information as conditioning context. Decode and manually inspect several labeled examples, including a tool call and a long trajectory, and assert nonzero target counts.

TRL supports conversational data and assistant-only loss, but the latter requires a template that provides generation boundaries. Verify Qwen2.5's actual template rather than relying on a flag. Add and verify a training-only boundary annotation or use an explicit, tested label mask while keeping the rendered serving text equivalent. Check end-of-message and padding handling. [TRL SFT documentation](https://huggingface.co/docs/trl/sft_trainer).

### D. Run a small, staged LoRA pilot

Owner: Weitao.

These are starting settings to validate, not claimed optimal hyperparameters:

| Setting | Initial pilot choice |
| --- | --- |
| Model | Qwen2.5-Coder-1.5B-Instruct |
| Adaptation | LoRA rank 16, alpha 32, dropout 0.05, bias none |
| Target modules | q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj; verify names on each model |
| Optimizer | AdamW, learning rate 1e-4, warmup ratio 0.03, gradient clipping 1.0 |
| Memory controls | Microbatch 1, gradient accumulation initially 8, gradient checkpointing, training KV cache disabled |
| Precision | BF16 where supported and feasible; otherwise one documented QLoRA policy (4-bit NF4 with a supported compute dtype) |
| Length | 4K-8K for initial mechanics, then the intended common production length |
| Packing | Off initially; enable only after boundaries, attention isolation, and loss masks are verified |
| Pilot size | First 4-8 examples for an overfit check; then 32-64 training trajectories for 50-100 optimizer steps |

1. Run a forward/backward check; confirm finite loss, nonzero adapter gradients, frozen base weights, and parameter updates restricted to intended trainable modules.
2. Overfit 4-8 known examples enough to show a clear training-loss decline. This checks learnability and masking, not generalization.
3. Run the short held-out pilot. Log loss, validation loss, actual processed/target tokens, token throughput, peak allocated/reserved VRAM, wall time, GPU count, and GPU hours. Exclude warmup from steady-state throughput and identify measurement boundaries.
4. Save adapter, optimizer/scheduler state, RNG state, tokenizer/template, and config. Resume briefly from a checkpoint and verify correct continuation.
5. In a fresh process, reload the exact base plus adapter. Compare fixed-prompt outputs/logits before save and after reload within numerical tolerance. If merging for serving, validate merged versus adapter behavior too, and document quantization/merge limitations.
6. Load the pilot adapter through the same serving path and run the same small development task list as its matching baseline; export and grade patches. Report valid-action rate and resolution outcomes without requiring improvement from such a short run.
7. Run a few training steps with 3B and 7B at the proposed production length to expose memory problems early. Adjust the common precision/context/batch policy before the main runs. Estimate nine-run cost using measured throughput for each size; a 1.5B timing alone is insufficient.

Train and serve sequentially on the local GPU. Shut down the inference model before training and vice versa. Avoid promising a particular 7B context length until it has been measured on the actual hardware.

### Suggested sequence

| Period | Work | Lead | Evidence |
| --- | --- | --- | --- |
| Sep 28-30 | Pin releases; recover provenance; normalize histories | Weitao | Raw manifest and validated conversion |
| Oct 1-3 | Overlap checks, task-level split, token/length audit | Weitao | Audited datasets, statistics, exclusion report |
| Oct 4-6 | Loss-mask checks, backward pass, tiny overfit | Weitao | Decoded label examples and declining loss |
| Oct 7-9 | Short pilot, save/resume/reload, scaffold evaluation | Both | Adapter checkpoint and official development reports |
| Oct 10-11 | 3B/7B feasibility probes, cost estimate, handoff | Both | Resource table and frozen training recipe |

**Milestone 2 passes when:** retained rows have traceable provenance and valid tools; split tasks do not overlap; the overlap audit and token accounting are reproducible; adapter weights demonstrably update with correct labels; save/resume/reload work; the adapter completes the shared agent-to-grader workflow; and resource feasibility is measured for all three model sizes. Loss reduction alone does not establish improved task resolution.

## 5. Planned repository outputs

These are proposed implementation files, not files already implemented:

- docs/environment.md, docs/experiment_protocol.md, docs/data_audit.md, docs/pilot_report.md.
- configs/models.yaml, configs/agent.yaml, configs/evaluation.yaml, configs/lora_sft.yaml.
- manifests/versions.json, manifests/eval_100.json, manifests/dev_tasks.json, manifests/swegym_sources.json.
- scripts/check_environment.sh, scripts/validate_harness.sh, scripts/serve_model.sh.
- src/agent/run.py and src/evaluation/export_predictions.py.
- src/data/prepare_swegym.py, src/data/audit_overlap.py, src/data/token_stats.py.
- src/training/train_sft.py and src/training/validate_checkpoint.py.
- results/smoke/ and results/pilot/ for metrics, trajectories, predictions, reports, and run manifests.
- data/ and checkpoints/ for local large artifacts, excluded from ordinary Git commits; publish hashes and regeneration instructions.

## 6. Responsibility and handoff

Weitao owns data normalization, provenance, overlap checks, loss masking, training, and training-efficiency measurements. Qingyao owns the shared scaffold, task selection, inference policy, official grader, rollout metrics, and patch export. Both agree on the message/tool schema, context policy, tokenizer/template, version manifest, and acceptance evidence before main training.

Critical path: GPU/Docker checks -> grader controls -> checkpoint and tool compatibility -> baseline development run -> audited data and loss masks -> 1.5B pilot -> reload and agent evaluation -> 3B/7B feasibility -> main-run configuration.

By the handoff to milestone 3, the reusable pipeline should work, while full SWE-smith/SWE-Master processing, final equal-token subset selection, nine production training runs, and twelve full evaluations remain scheduled later.

## 7. Interpretation limits to record from the start

- Released datasets differ in teachers, curation, repositories, and original tool frameworks. Standardizing training controls the released-data comparison but does not isolate the causal effect of underlying task source alone. Record these differences in the final study.
- Equal token budgets do not imply equal GPU hours across model sizes; compute cost is an outcome to measure.
- One attempt on 100 tasks yields a coarse, uncertain resolution estimate. Later analysis should retain per-task paired outcomes and report confidence intervals; development pilots do not support scaling claims.
- A hardware-driven change to precision, context, or scaffold must be versioned and applied consistently before the main comparisons. If the local GPU cannot support the agreed recipe, revise that common recipe or arrange additional compute before launching the nine-run matrix.
